<?php

import('lib.pkp.classes.plugins.ImportExportPlugin');
import('lib.pkp.classes.xml.XMLCustomWriter');


class RepecExportPlugin extends ImportExportPlugin
{
    function register($category, $path, $mainContextId = NULL)
    {
        $success = parent::register($category, $path, $mainContextId);

        $this->addLocaleData();
        AppLocale::requireComponents(LOCALE_COMPONENT_APP_EDITOR);
        $this->addLocaleData();

        return $success;
    }

    function getName()
    {
        return 'RepecExportPlugin';
    }

    function getDisplayName()
    {
        return __('plugins.importexport.repec.displayName');
    }

    function displayName()
    {
        return 'Repec export plugin';
    }

    function getDescription()
    {
        return __('plugins.importexport.repec.description');
    }

    function multiexplode($delimiters, $string)
    {

        $ready = str_replace($delimiters, $delimiters[0], $string);
        $launch = explode($delimiters[0], $ready);
        return $launch;
    }

    function formatXml($simpleXMLElement)
    {
        $xmlDocument = new DOMDocument();
        $xmlDocument->preserveWhiteSpace = false;
        $xmlDocument->formatOutput = true;
        $xmlDocument->loadXML($simpleXMLElement->saveXML());
        return $xmlDocument->saveXML();
    }

    function &generateIssueDom(&$doc, &$journal, &$issue)
    {
        $root =& XMLCustomWriter::createElement($doc, 'xml');

        $sectionDao =& DAORegistry::getDAO('SectionDAO');
        $publishedArticleDao =& DAORegistry::getDAO('PublishedArticleDAO');
        $articleFileDao =& DAORegistry::getDAO('ArticleGalleyDAO');
        $submissionKeywordDao = DAORegistry::getDAO('SubmissionKeywordDAO');
        foreach ($sectionDao->getByIssueId($issue->getId()) as $section) {

            foreach ($publishedArticleDao->getPublishedArticlesBySectionId($section->getId(), $issue->getId()) as $article) {

                if (!$article->getStartingPage()) continue;

                $locales = array_keys($article->_data['title']);
                $article_elem = XMLCustomWriter::createChildWithText($doc, $root, 'xml', '', true);
                XMLCustomWriter::createChildWithText($doc, $article_elem,'xml', 'Template-Type: ReDIF-Article 1.0', true);

                foreach ($article->getAuthors() as $author) {
                    $author_FirstName = '';
                    $author_MiddleName = '';
                    $author_LastName = '';

                    if (method_exists($author, "getLocalizedFirstName")) { 
                        $author_FirstName = $author->getLocalizedFirstName();
                        $author_MiddleName = $author->getLocalizedMiddleName();
                        $author_LastName = $author->getLocalizedLastName();
                    } elseif (method_exists($author, "getLocalizedGivenName")) {
                        $author_FirstName = $author->getLocalizedGivenName();
                        $author_MiddleName = '';
                        $author_LastName = $author->getLocalizedFamilyName();
                    } else {
                        $author_FirstName = $author->getFirstName();
                        $author_MiddleName = $author->getMiddleName();
                        $author_LastName = $author->getLastName();
                    }

                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Author: ' . $author_FirstName . ' ' . $author_LastName, true);
                }

                foreach ($locales as $loc) {
                    $lc = explode('_', $loc);
                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Title: ' . $article->getLocalizedTitle($loc), true);
                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Abstract: ' . strip_tags($article->getLocalizedData('abstract', $loc)), true);
                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Publication-Status: Published in "Journal of Community Positive Practices", ' . $issue->getNumber() . ' ' .  $issue->getYear() , true);

                    if (is_a($article, 'PublishedArticle')) {
                        foreach ($article->getGalleys() as $galley) {
                            $url = Request::url($journal->getPath()) . '/article/download/' . $article->getBestArticleId() . '/' . $galley->getBestGalleyId();
                            break;
                        }
                        XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','File-URL: ' . $url, true);
                        XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','File-Format: Application/pdf', true);
                        XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','File-Function: First version, '.$issue->getYear(), true);
                    }

                    $kwds = $submissionKeywordDao->getKeywords($article->getId(), array($loc));
                    $kwds = $kwds[$loc];
                    $j = 0;
                    foreach ($kwds as $k) {
                       $combine = $combine . ', ' . $k;
                        $j++;
                    }
                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Keywords:' . substr($combine, 1), true);
                    $combine = '';

                    if ($j == 0) {
                        XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml', " ", true);
                    }

                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml','Pages: ' . $article->getStartingPage(). '-'. $article->getEndingPage(), true);
                    XMLCustomWriter::createChildWithText($doc, $article_elem, 'xml', 'Number: '. $issue->getNumber() . substr($issue->getYear(), -2) . substr($article->getStoredPubId('doi'), -1), true);
                }
            }
        }
        return $root;
    }

    function exportIssue(&$journal, &$issue, $outputFile = null)
    {
        $doc =& XMLCustomWriter::createDocument();

        $issueNode = $this->generateIssueDom($doc, $journal, $issue);
        XMLCustomWriter::appendChild($doc, $issueNode);
        if (!empty($outputFile)) {
            if (($h = fopen($outputFile, 'wb')) === false) return false;
            fwrite($h, XMLCustomWriter::getXML($doc));
            fclose($h);
        } else {

            header("Content-Type: application/xml");
            header("Cache-Control: private");
            header("Content-Disposition: attachment; filename=\"" . $journal->getLocalizedAcronym() . '_' . $issue->getYear() . '_' . $issue->getNumber() . ".rdf\"");
            echo $this->formatXml($doc);
        }
        return true;
    }


    function display($args, $request)
    {
        parent::display($args, $request);
        $issueDao =& DAORegistry::getDAO('IssueDAO');
        $journal =& $request->getJournal();
        switch (array_shift($args)) {
            case 'exportIssue':
                $issueId = array_shift($args);
                $issue = $issueDao->getById($issueId, $journal->getId());
                if (!$issue) $request->redirect();
                $this->exportIssue($journal, $issue);
                break;

            default:

                $journal =& Request::getJournal();
                $issueDao =& DAORegistry::getDAO('IssueDAO');
                $issues = $issueDao->getIssues($journal->getId(), Handler::getRangeInfo($request, 'issues'));

                $templateMgr = TemplateManager::getManager($request);

                if (method_exists($this, "getTemplateResource")) {
                    $templateMgr->assignByRef('issues', $issues);
                    $templateMgr->display($this->getTemplateResource('issues.tpl'));
                } else {
                    $templateMgr->assign_by_ref('issues', $issues);
                    $templateMgr->display($this->getTemplatePath() . '/templates/issues.tpl');
                }
        }
    }

    function executeCLI($scriptName, &$args)
    {
        $this->usage($scriptName);
    }

    function usage($scriptName)
    {
        echo "test";
    }
}
